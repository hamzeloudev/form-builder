import { DraggableField } from './DraggableField';
import { DraggableFieldType } from './DraggableFieldType';

export default {
  DraggableField,
  DraggableFieldType,
};
