import CheckboxField from './CheckboxField';
import SelectField from './SelectField';
import TextField from './TextField';

export default {
  CheckboxField,
  SelectField,
  TextField,
};
